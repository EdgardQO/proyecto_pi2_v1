package com.proyecto_pi2.app_administracion_de_flota;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppAdministracionDeFlotaApplicationTests {

	@Test
	void contextLoads() {
	}

}
