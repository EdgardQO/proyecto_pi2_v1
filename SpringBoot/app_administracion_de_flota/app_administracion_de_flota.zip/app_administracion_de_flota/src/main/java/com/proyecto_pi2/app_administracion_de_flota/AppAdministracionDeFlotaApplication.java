package com.proyecto_pi2.app_administracion_de_flota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppAdministracionDeFlotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppAdministracionDeFlotaApplication.class, args);
	}

}
